package com.crossover.e2e;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import junit.framework.Assert;
import junit.framework.TestCase;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;


/**
 * This class contains methods to test Gmail mailing service
 * 
 * @author Prasad Hegde
 * @version 1.0
 * @since 2020-04-01
 */

@SuppressWarnings("deprecation")
public class GMailTest extends TestCase {

	private WebDriver driver;
	private Properties properties = new Properties();
	private WebDriverWait wait;
	private JavascriptExecutor js;
	public Logger log = Logger.getLogger(GMailTest.class);

	/**
	 * This method performs test setup activity such as - Loading Properties file -
	 * Initializing browser driver and wait object
	 * 
	 * @param Nothing
	 * @return Nothing
	 * @throws IOException
	 * @throws FileNotFoundException
	 * @exception Exception
	 *                is raised when setup fails
	 */
	@Before
	public void setUp() throws FileNotFoundException, IOException {

		properties.load(new FileReader(new File("src/test/resources/test.properties")));
		String log4jConfigFile = System.getProperty("user.dir")
				+ "//src//test//resources//log4j.properties";
		PropertyConfigurator.configure(log4jConfigFile);
		// Dont Change below line. Set this value in test.properties file incase you
		// need to change it..
		System.setProperty("webdriver.chrome.driver", properties.getProperty("webdriver.chrome.driver"));
		driver = new ChromeDriver();
		wait = new WebDriverWait(driver, 30);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	/**
	 * This method performs test Teardown activity such as - destroying the browser
	 * driver object
	 * 
	 * @param Nothing
	 * @return Nothing
	 * @exception Exception
	 *                is raised when teardown fails
	 */
	@After
	public void tearDown() {
		driver.quit();
	}

	/**
	 * This method is used to login to Gmail
	 * 
	 * @param Nothing
	 * @return Nothing
	 * @throws InterruptedException
	 * @exception Exception
	 *                is raised in case of failure
	 */
	public void loginToGmail() throws InterruptedException {

		driver.get(properties.getProperty("stackoverflow.url"));
		driver.manage().window().maximize();

		WebElement stackOverFlowLogin = driver.findElement(By.xpath("//a[contains(text(), 'Log in')]"));
		stackOverFlowLogin.click();

		WebElement googleLink = driver.findElement(By.xpath("//button[@data-provider = 'google']"));
		googleLink.click();

		WebElement userElement = driver.findElement(By.id("identifierId"));
		userElement.sendKeys(properties.getProperty("username"));

		WebElement clickNext = driver.findElement(By.xpath("//span[contains(text(), 'Next')]"));
		clickNext.click();

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@type='password']")))
				.sendKeys(properties.getProperty("password"));

		WebElement clickNextButton = driver.findElement(By.xpath("//span[contains(text(), 'Next')]"));
		clickNextButton.click();
		try {
			Select newAccountDropDown = new Select(driver.findElement(By.xpath("//select[@id='job-opportunities-required']")));
			newAccountDropDown.selectByValue("NotLooking");
			WebElement submit = driver.findElement(By.xpath("//button[@id='confirm-submit']"));
			submit.click();
			
		}catch(NoSuchElementException e) {
			
		}
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(@aria-label,'Inbox')]")));

		driver.get(properties.getProperty("gmail.url"));

	}

	/**
	 * This method is used to navigate to Settings option
	 * 
	 * @param Nothing
	 * @return Nothing
	 * @exception Exception
	 *                is raised in case of failure
	 */
	public void navigateToSettings() {

		wait.until(ExpectedConditions.visibilityOfElementLocated(
				By.xpath("//div[@data-tooltip='Older']//following::div[@data-tooltip='Settings']"))).click();

		WebElement dropdownSettings = driver.findElement(By.xpath("//div[@id='ms']/div[contains(text(), 'Settings')]"));
		dropdownSettings.click();

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Labels']")));

	}

	/**
	 * This method is used to Show Social label in settings
	 * 
	 * @param label
	 *            This is a param of type string.
	 * @return Nothing
	 * @throws InterruptedException 
	 * @exception Exception
	 *                is raised in case of failure
	 */
	public void showLabel(String label) throws InterruptedException {

		WebElement labelElement = driver.findElement(By.xpath("//a[text()='Labels']"));
		labelElement.click();

		js = (JavascriptExecutor) driver;
		WebElement showLabel = driver
				.findElement(By.xpath("//div[text()='" + label + "']//following::span[text()='show'][1]"));
		js.executeScript("arguments[0].scrollIntoView();", showLabel);
		Thread.sleep(4000);
		String showColor = showLabel.getCssValue("Color");
		if (!showColor.equals("rgb(32, 33, 36)")) {
			showLabel.click();
		}

	}

	/**
	 * This method is used to enable labels in settings
	 * 
	 * @param label
	 *            This param is a list string labels.
	 * @return Nothing
	 * @exception Exception
	 *                is raised in case of failure
	 */
	public void enableLabels(List<String> labelNames) {

		boolean isLabelEnabled = false;
		WebElement inbox = driver.findElement(By.xpath("//a[text()= 'Labels']//following::a[text()='Inbox']"));
		inbox.click();

		for (String label : labelNames) {
			WebElement labelElement = driver
					.findElement(By.xpath("//label[text()= '" + label + "']/parent::td/preceding-sibling::td/input"));
			if (!labelElement.isSelected()) {
				labelElement.click();
				isLabelEnabled = true;
			}
		}

		if (isLabelEnabled) {
			WebElement saveButton = driver
					.findElement(By.xpath("(//div[@role='navigation']/button[text()='Save Changes'])[2]"));
			saveButton.click();
		} else {
			WebElement gmailHome = driver.findElement(By.xpath("//a[@title='Gmail']/img"));
			gmailHome.click();
		}

	}

	/**
	 * This method is used to compose email
	 * 
	 * @param mailDetail
	 *            This param is a dictionary string which contains username, subject
	 *            and mailbody.
	 * @return Nothing
	 * @throws InterruptedException 
	 * @exception Exception
	 *                is raised in case of failure
	 */
	public void composeEmail(HashMap<String, String> mailDetail) throws InterruptedException {

		WebElement composeElement = driver.findElement(By.xpath("//div[contains(text(),'Compose')]"));
		composeElement.click();

		String userName = mailDetail.get("username");
		WebElement mailTo = driver.findElement(By.xpath("//textarea[@name='to']"));
		mailTo.clear();
		mailTo.sendKeys(String.format("%s@gmail.com", userName));

		String subjectName = mailDetail.get("subject");
		WebElement mailSubject = driver.findElement(By.xpath("//input[@name='subjectbox']"));
		mailSubject.sendKeys(subjectName);

		String body = mailDetail.get("body");
		Thread.sleep(1000);
		WebElement mailBody =driver.findElement(By.xpath("//div[@role='textbox']"));
		 mailBody.sendKeys(body);

	}

	/**
	 * This method is used to enter label in label text field
	 * 
	 * @param label
	 *            This param is a string label
	 * @return Nothing
	 * @exception Exception
	 *                is raised in case of failure
	 */
	public void enterLabelInLabelField(String label) {

		WebElement labelText = driver.findElement(By.xpath("//input[@aria-label='Label-as menu open']"));
		labelText.clear();

		labelText.sendKeys(label);

	}

	/**
	 * This method is used to add label to email
	 * 
	 * @param label
	 *            This param is a list of string label
	 * @return Nothing
	 * @throws InterruptedException 
	 * @exception Exception
	 *                is raised in case of failure
	 */
	public void addLabelToEmail(List<String> emailLabels) throws InterruptedException {

		WebElement moreOptions = driver.findElement(By.xpath("//div[@aria-label=\"More options\"]"));
		moreOptions.click();

		WebElement label = driver.findElement(By.xpath("//div[contains(text(), 'Label')]"));
		label.click();
		Thread.sleep(1000);

		for (String labels : emailLabels) {
			enterLabelInLabelField(labels);
			WebElement labelCheckbox = driver.findElement(By.xpath("//div[@title='" + labels + "']"));
			labelCheckbox.click();

		}

	}

	/**
	 * This method is used to send mail
	 * 
	 * @param Nothing
	 * @return Nothing
	 * @exception Exception
	 *                is raised in case of failure
	 */
	public void sendEmail() {

		WebElement send = driver.findElement(By.xpath("//*[@role='button' and text()='Send']"));
		send.click();

	}

	/**
	 * This method is used to navigate to folders in sidebar
	 * 
	 * @param option
	 *            This param is a list of sequence of strings which needs to be
	 *            accessed. Ex: ["Categoies", "Social"]
	 * @return Nothing
	 * @throws InterruptedException
	 * @exception Exception
	 *                is raised in case of failure
	 */
	public void navigateToSideBarOptions(List<String> options) throws InterruptedException {
		if (options.size() > 1) {
			try {
				WebElement labelOption = driver.findElement(By.xpath("//a[@title='"+ options.get(options.size()-1) + "']"));
				js.executeScript("arguments[0].click()", labelOption);
				Thread.sleep(5000);
				return;
			}
			catch (NoSuchElementException e) {
				log.info("Label is not visible.. Expanding parent folder: Category ");
			}
		}
		WebElement sideBarOption = driver.findElement(By.xpath("//a[@title='"+ options.get(0) + "']"));
		js.executeScript("arguments[0].scrollIntoView()", sideBarOption);
		js.executeScript("arguments[0].click()", sideBarOption);
		
		options.remove(0);
		for (String option: options) {
			driver.findElement(By.xpath("//a[@title='"+ option + "']")).click();
		}
		Thread.sleep(6000);
	}


	/**
	 * This method is used to select email based on the sendername and subject type
	 * 
	 * @param emailMap
	 *            This param is a dictionary containing sendername and subject name
	 * @return Nothing
	 * @exception Exception
	 *                is raised in case of failure
	 */
	public WebElement selectEmail(HashMap<String, String> emailMap) {
		WebElement retval = null;
		List<WebElement> mailTables = driver.findElements(By.xpath(
				"//div[@data-tooltip='Older']//following::div[@data-tooltip='Settings']//following::table"));
		int tableSize = mailTables.size();
		WebElement mailTable =driver.findElement(By.xpath(
				"//div[@data-tooltip='Older']//following::div[@data-tooltip='Settings']//following::table["+tableSize+"]/tbody"));

		List<WebElement> rows = mailTable.findElements(By.xpath("tr"));
		for (WebElement row : rows) {
			if (row.getText() != null && row.getText().contains(emailMap.get("SenderName"))
					&& row.getText().contains(emailMap.get("MessageSubject"))) {
				List<WebElement> columns = row.findElements(By.xpath("td"));
				retval = row;
				break;
			}
		}

		return retval;

	}

	/**
	 * This method is used to star selected mail
	 * 
	 * @param rowElement
	 *            This param is a webElement row
	 * @return Nothing
	 * @exception Exception
	 *                is raised in case of failure
	 */
	public void starMail(WebElement rowElement) {

		List<WebElement> columns = rowElement.findElements(By.xpath("td"));
		columns.get(2).click();

	}

	/**
	 * This method is used to open selected Mail
	 * 
	 * @param mailRow
	 *            This param is a webElement row
	 * @return Nothing
	 * @throws InterruptedException 
	 * @exception Exception
	 *                is raised in case of failure
	 */
	public void openMail(WebElement mailRow) throws InterruptedException {
		mailRow.click();
		Thread.sleep(2000);
	}

	/**
	 * This method is used to verify mail contents
	 * 
	 * @param mailContents
	 *            This param is a dictionary containing Subject and mailBody
	 * @return Nothing
	 * @exception Exception
	 *                is raised in case of failure
	 */
	@SuppressWarnings("deprecation")
	public void verifyMailContents(HashMap<String, String> mailContents) throws Exception {

		if (mailContents.containsKey("subject")) {
			WebElement subject = driver.findElement(By.xpath("//*[@class='hP']"));
			String subjectText = subject.getText();
			log.info("Displayed Email subject is "+subjectText);
			Assert.assertEquals(subjectText, mailContents.get("subject"));

		}

		if (mailContents.containsKey("mailBody")) {
			String actualEmailBodyText = driver
					.findElement(By.xpath("(//table[@role='presentation'])[2]//div[@role='listitem']//div[@dir='ltr']"))
					.getText();
			log.info("Displayed Email body is "+actualEmailBodyText);
			Assert.assertEquals(actualEmailBodyText, mailContents.get("mailBody"));

		}

	}

	@Test
	public void testSendEmail() throws Exception {
		
		log.info("Login into Gmail");
		loginToGmail();

		navigateToSettings();
		showLabel("Social");

		log.info("Enable Social Label");
		List<String> labels = new ArrayList<>(Arrays.asList("Primary", "Social"));
		enableLabels(labels);

		log.info("Compose email by passing username, subject and message body");
		HashMap<String, String> mailDetails = new HashMap<String, String>();
		log.info(properties.getProperty("username"));
		mailDetails.put("username", properties.getProperty("username"));
		mailDetails.put("subject", properties.getProperty("email.subject"));
		mailDetails.put("body", properties.getProperty("email.body"));
		composeEmail(mailDetails);

		log.info("Add Social label to email");
		labels.remove(0);
		addLabelToEmail(labels);

		log.info("Send Email");
		sendEmail();

		log.info("Navigate to Categories->Social in Sidebar menu");
		List<String> options = new ArrayList<>(Arrays.asList("Categories", "Social"));
		navigateToSideBarOptions(options);

		log.info("Select the mail which was sent in previous step");
		HashMap<String, String> emailMap = new HashMap<String, String>();
		emailMap.put("SenderName", "me");
		emailMap.put("MessageSubject", properties.getProperty("email.subject"));
		WebElement mailRow = selectEmail(emailMap);
		if (mailRow == null) {
			log.info("Could not capture the mail row"); // fail the test
			Assert.fail();
		}

		log.info("Add Star to the mail");
		starMail(mailRow);

		log.info("Open the mail");
		openMail(mailRow);

		log.info("Verify Mail contents");
		HashMap<String, String> mailContents = new HashMap<String, String>();
		mailContents.put("subject", properties.getProperty("email.subject"));
		mailContents.put("mailBody", properties.getProperty("email.body"));
		verifyMailContents(mailContents);
	}
}